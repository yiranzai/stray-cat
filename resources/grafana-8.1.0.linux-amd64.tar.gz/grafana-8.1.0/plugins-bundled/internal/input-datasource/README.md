# Direct Input Data Source -  Bundled Plugin

This data source lets you define results directly in CSV.  The values are stored either in a shared data source, or directly in panels.
